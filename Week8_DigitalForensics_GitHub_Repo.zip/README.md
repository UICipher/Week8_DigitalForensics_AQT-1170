# Week 8: Digital Forensics, Disk Image Investigation with Autopsy

AstraQuantum Tech | Summer of Cybersecurity 2026
Instructor: Muhammad Faizan Khan
Student ID: AQT-1170

## About

This is my Week 8 practical assignment. I used Autopsy to investigate a public training disk image and documented one interesting artifact.

## Evidence

| Item | Details |
|---|---|
| Image | nps-2009-canon2-gen6.E01 |
| Format | E01 (EnCase / Expert Witness) |
| Source | Digital Corpora, NPS Test Disk Images: https://digitalcorpora.org/corpora/disk-images/ |
| Size | 31,129,600 bytes |
| MD5 | 5ab5d74c7124d4f3e1f13a4a5a044129 |
| SHA-1 | e6212ddcabcf13f243684fa7fef952704af0b0ae |

The evidence image is not included in this repository. It can be downloaded from the source above.

## Tools

- Autopsy 4.23.1 (Sleuth Kit Labs)
- Ingest modules: Recent Activity, Hash Lookup, File Type Identification, Extension Mismatch Detector, Embedded File Extractor, Keyword Search, PhotoRec Carver

## Key artifact

- File: f0000010.jpg (carved JPEG)
- Path: /img_nps-2009-canon2-gen6.E01/vol_vol2/$CarvedFiles/1/f0000010.jpg
- Size: 3,613 bytes
- MD5: 1a02644fb8f23f590a8ebf9de21c7dba
- Timestamps: none (all zero)
- Content: a computer monitor with a sheet of paper showing the number 1

This shows that a photo existed on the camera card and is no longer linked in the file system. It does not prove when it was taken, who deleted it, or why.

## Screenshots

1. screenshots/01_case_add_data_source.jpg: case created, Add Data Source started
2. screenshots/02_data_source_added.jpg: image added, ingest running
3. screenshots/03_deleted_files_filesystem.jpg: Deleted Files > File System (3)
4. screenshots/04_artifact_file_metadata.jpg: metadata of f0000010.jpg
5. screenshots/05_artifact_application_view.jpg: picture content of f0000010.jpg

## Report

The full PDF report is in the report folder.

## Note

Only a public training image was used. No private or real seized data was examined.
